import com.sun.net.httpserver.HttpServer;
import com.sun.net.httpserver.HttpExchange;
import java.io.IOException;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Date;
import java.sql.Time;

public class HospitalServer {

    public static Connection connect() throws SQLException {

        return DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/hospital_management_system",
                "root",
                ""
        );
    }

    public static void main(String[] args) throws IOException {

        HttpServer server = HttpServer.create(
                new InetSocketAddress(8080), 0);

        server.createContext("/appointments", exchange -> {

            exchange.getResponseHeaders().add(
                    "Access-Control-Allow-Origin", "*");

            exchange.getResponseHeaders().add(
                    "Access-Control-Allow-Methods", "POST, OPTIONS");

            exchange.getResponseHeaders().add(
                    "Access-Control-Allow-Headers", "Content-Type");

            if (exchange.getRequestMethod().equalsIgnoreCase("OPTIONS")) {
                exchange.sendResponseHeaders(204, -1);
                return;
            }

            if (!exchange.getRequestMethod().equalsIgnoreCase("POST")) {
                sendResponse(exchange, 405, "Method not allowed.");
                return;
            }

            try {

                String data = new String(
                        exchange.getRequestBody().readAllBytes(),
                        StandardCharsets.UTF_8);

                String patientID = getValue(data, "patientID");
                String patientName = getValue(data, "patientName");
                String doctorID = getValue(data, "doctorID");
                String appointmentDate = getValue(data, "appointmentDate");
                String appointmentTime = getValue(data, "appointmentTime");
                String reason = getValue(data, "reason");

                try (Connection con = connect()) {

                    // Verify Patient

                    String patientSQL = "SELECT patient_id FROM patient_records "
                            + "WHERE patient_id = ? AND patient_names = ?";

                    PreparedStatement patientStatement =
                            con.prepareStatement(patientSQL);

                    patientStatement.setInt(1, Integer.parseInt(patientID));
                    patientStatement.setString(2, patientName);

                    ResultSet patientResult =
                            patientStatement.executeQuery();

                    if (!patientResult.next()) {

                        sendResponse(exchange, 404,
                                "Patient ID or name does not match our records.");
                        return;
                    }

                    // Verify Doctor

                    String doctorSQL = "SELECT doctors_id FROM doctors_records "
                            + "WHERE doctors_id = ?";

                    PreparedStatement doctorStatement =
                            con.prepareStatement(doctorSQL);

                    doctorStatement.setInt(1, Integer.parseInt(doctorID));

                    ResultSet doctorResult =
                            doctorStatement.executeQuery();

                    if (!doctorResult.next()) {

                        sendResponse(exchange, 404,
                                "Doctor ID does not exist.");
                        return;
                    }

                    // Insert Appointment

                    String insertSQL = "INSERT INTO appointments "
                            + "(patient_id, doctors_id, appointment_date, "
                            + "appointment_time, reason) "
                            + "VALUES (?, ?, ?, ?, ?)";

                    PreparedStatement insertStatement =
                            con.prepareStatement(insertSQL);

                    insertStatement.setInt(1, Integer.parseInt(patientID));
                    insertStatement.setInt(2, Integer.parseInt(doctorID));

                    insertStatement.setDate(3,
                            Date.valueOf(appointmentDate));

                    insertStatement.setTime(4,
                            Time.valueOf(appointmentTime + ":00"));

                    insertStatement.setString(5, reason);

                    insertStatement.executeUpdate();

                    sendResponse(exchange, 200,
                            "Appointment booked successfully!");

                }

            } catch (Exception e) {

                e.printStackTrace();

                sendResponse(exchange, 500,
                        "Error booking appointment: " + e.getMessage());
            }
        });

        server.start();

        System.out.println("Swingstars Hospital Server Started");
        System.out.println("Server running on http://localhost:8080");
    }

    private static String getValue(String data, String key) {

        String search = "\"" + key + "\":";
        int start = data.indexOf(search);

        if (start == -1) {
            return "";
        }

        start += search.length();

        while (start < data.length()
                && (data.charAt(start) == ' '
                || data.charAt(start) == '"')) {

            start++;
        }

        int end = data.indexOf('"', start);

        if (end == -1) {
            end = data.indexOf(',', start);
        }

        if (end == -1) {
            end = data.indexOf('}', start);
        }

        if (end == -1) {
            return "";
        }

        return data.substring(start, end).trim();
    }

    private static void sendResponse(
            HttpExchange exchange, int status, String message)
            throws IOException {

        byte[] response = message.getBytes(StandardCharsets.UTF_8);

        exchange.sendResponseHeaders(status, response.length);

        try (OutputStream output = exchange.getResponseBody()) {
            output.write(response);
        }
    }
}